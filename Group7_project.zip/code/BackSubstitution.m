function x=BackSubstitution(EchelonForm)
n=height(EchelonForm);
x=zeros(n,1);
x(n)=EchelonForm(n,n+1)/EchelonForm(n,n);
for k=n-1:-1:1
    x(k)=(EchelonForm(k,n+1)-EchelonForm(k,k+1:n)*x(k+1:n))/EchelonForm(k,k);
end
return