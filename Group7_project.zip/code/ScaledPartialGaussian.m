function U=ScaledPartialGaussian(A,b)
n=length(b);
scales=zeros(n,1);
Aug=[A b];%الحاق کردن ماتریس ضرایب و بردار 
for i=1:n
    scales(i)=max(abs(Aug(i,1:n)));%هر عنصر از بردار مقیاس‌ها برابر با ماکسیمم قدر مطلق عناصر روی یک سطر بردار ضرایب
end
for j=1:n-1
    for a=j:n
        scaledColumn(a)=abs(Aug(a,j))/scales(a);%عناصر زیر قطر در ستونی که در حال محورگیری آنیم بر مقیاس‌هایشان تقسیم می‌شوند
    end

    [m,p]=max(abs(scaledColumn(j:n)));%ماکسیم مقادیر مقیاس شده در ستون محورگیری را به همراه اندیس آن می‌یابیم
  
    r=Aug(j,:);
    Aug(j,:)=Aug(p+j-1,:); %جابجایی سطر‌ و قرارگیری سطر با ماکسیمم مقدار محوری در محل محورگیری
    Aug(p+j-1,:)=r

    for i=j:n-1
        m=Aug(i+1,j)/Aug(j,j);  %مانند حذف گاوسی عادی مضربی از سطر محوری را از بقیه‌سطرها کم می‌کنیم تا درایه‌ی ستون مربوطه ۰ شود
        Aug(i+1,:)=Aug(i+1,:)-m*Aug(j,:);
    end  
end
U=Aug;
return





