load('LinSysG7.mat','A');
load("LinSysG7.mat","b");
EchelonForm=ScaledPartialGaussian(A,b);
BackSubstitution(EchelonForm)